package ch.bildspur.postfx.pass;

import processing.core.PApplet;

/**
 * Created by cansik on 14.05.17.
 */
public class InvertPass extends BasePass {
    private static final String PASS_NAME = "invertFrag";

    public InvertPass(PApplet sketch) {
        super(sketch, PASS_NAME);
    }
}
